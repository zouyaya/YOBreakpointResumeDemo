//
//  YODataBaseManager.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/12.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YODataBaseManager.h"
#import "FMDatabaseQueue.h"
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"


typedef NS_ENUM(NSInteger,YODBGetDateOption)
{
   YODBGetDateOptionAllCacheData = 0,      // 所有缓存数据
   YODBGetDateOptionAllDownloadingData,    // 所有正在下载的数据
   YODBGetDateOptionAllDownloadedData,     // 所有下载完成的数据
   YODBGetDateOptionAllUnDownloadedData,   // 所有未下载完成的数据
   YODBGetDateOptionAllWaitingData,        // 所有等待下载的数据
   YODBGetDateOptionModelWithUrl,          // 通过url获取单条数据
   YODBGetDateOptionWaitingModel,          // 第一条等待的数据
   YODBGetDateOptionLastDownloadingModel,  // 最后一条正在下载的数据

};

@interface YODataBaseManager ()

@property (strong, nonatomic) FMDatabaseQueue *dbQueue;

@end

@implementation YODataBaseManager


+(instancetype)shareManager
{
    static YODataBaseManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (manager == nil) {
            manager = [[self alloc]init];
        }
    });
    
    return manager;
}


- (instancetype)init
{
    if (self = [super init]) {
        [self creatVideoCachesTable];
    }
    
    return self;
}

// 创表
- (void)creatVideoCachesTable
{
    // 数据库文件路径
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"YODownloadVideoCaches.sqlite"];
    
    // 创建队列对象，内部会自动创建一个数据库, 并且自动打开
    _dbQueue = [FMDatabaseQueue databaseQueueWithPath:path];
    [_dbQueue inDatabase:^(FMDatabase *db) {
        // 创表
        BOOL result = [db executeUpdate:@"CREATE TABLE IF NOT EXISTS t_videoCaches (id integer PRIMARY KEY AUTOINCREMENT, vid text, fileName text, url text, resumeData blob, totalFileSize integer, tmpFileSize integer, state integer, progress float, lastSpeedTime integer, intervalFileSize integer, lastStateTime integer)"];
        if (result) {
            //            YOLog(@"视频缓存数据表创建成功");
        }else {
            NSLog(@"视频缓存数据表创建失败");
        }
    }];
}

// 插入数据
- (void)insertModel:(YODownloadModel *)model
{
    [_dbQueue inDatabase:^(FMDatabase *db) {
        BOOL result = [db executeUpdate:@"INSERT INTO t_videoCaches (vid, fileName, url, resumeData, totalFileSize, tmpFileSize, state, progress, lastSpeedTime, intervalFileSize, lastStateTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", model.vid, model.fileName, model.url, model.resumeData, [NSNumber numberWithInteger:model.totalFileSize], [NSNumber numberWithInteger:model.tmpFileSize], [NSNumber numberWithInteger:model.state], [NSNumber numberWithFloat:model.progress], [NSNumber numberWithInteger:0], [NSNumber numberWithInteger:0], [NSNumber numberWithInteger:0]];
        if (result) {
            //            YOLog(@"插入成功：%@", model.fileName);
        }else {
             NSLog(@"插入失败：%@", model.fileName);
        }
    }];
}

// 获取单条数据
- (YODownloadModel *)getModelWithUrl:(NSString *)url
{
    return [self getModelWithOption:YODBGetDateOptionModelWithUrl url:url];
}

// 获取第一条等待的数据
- (YODownloadModel *)getWaitingModel
{
    return [self getModelWithOption:YODBGetDateOptionWaitingModel url:nil];
}

// 获取最后一条正在下载的数据
- (YODownloadModel *)getLastDownloadingModel
{
    return [self getModelWithOption:YODBGetDateOptionLastDownloadingModel url:nil];
}

// 获取所有数据
- (NSArray<YODownloadModel *> *)getAllCacheData
{
    return [self getDateWithOption:YODBGetDateOptionAllCacheData];
}

// 根据lastStateTime倒叙获取所有正在下载的数据
- (NSArray<YODownloadModel *> *)getAllDownloadingData
{
    return [self getDateWithOption:YODBGetDateOptionAllDownloadingData];
}

// 获取所有下载完成的数据
- (NSArray<YODownloadModel *> *)getAllDownloadedData
{
    return [self getDateWithOption:YODBGetDateOptionAllDownloadedData];
}

// 获取所有未下载完成的数据
- (NSArray<YODownloadModel *> *)getAllUnDownloadedData
{
    return [self getDateWithOption:YODBGetDateOptionAllUnDownloadedData];
}

// 获取所有等待下载的数据
- (NSArray<YODownloadModel *> *)getAllWaitingData
{
    return [self getDateWithOption:YODBGetDateOptionAllWaitingData];
}

// 获取单条数据
- (YODownloadModel *)getModelWithOption:(YODBGetDateOption)option url:(NSString *)url
{
    __block YODownloadModel *model = nil;
    
    [_dbQueue inDatabase:^(FMDatabase *db) {
        FMResultSet *resultSet;
        switch (option) {
            case YODBGetDateOptionModelWithUrl:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches WHERE url = ?", url];
                break;
                
            case YODBGetDateOptionWaitingModel:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches WHERE state = ? order by lastStateTime asc limit 0,1", [NSNumber numberWithInteger:YODownloadStateWaiting]];
                break;
                
            case YODBGetDateOptionLastDownloadingModel:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches WHERE state = ? order by lastStateTime desc limit 0,1", [NSNumber numberWithInteger:YODownloadStateDownloading]];
                break;
                
            default:
                break;
        }
        
        while ([resultSet next]) {
            model = [[YODownloadModel alloc] initWithFMResultSet:resultSet];
        }
    }];
    
    return model;
}

// 获取数据集合
- (NSArray<YODownloadModel *> *)getDateWithOption:(YODBGetDateOption)option
{
    __block NSArray<YODownloadModel *> *array = nil;
    
    [_dbQueue inDatabase:^(FMDatabase *db) {
        FMResultSet *resultSet;
        switch (option) {
            case YODBGetDateOptionAllCacheData:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches"];
                break;
                
            case YODBGetDateOptionAllDownloadingData:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches WHERE state = ? order by lastStateTime desc", [NSNumber numberWithInteger:YODownloadStateDownloading]];
                break;
                
            case YODBGetDateOptionAllDownloadedData:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches WHERE state = ?", [NSNumber numberWithInteger:YODownloadStateFinish]];
                break;
                
            case YODBGetDateOptionAllUnDownloadedData:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches WHERE state != ?", [NSNumber numberWithInteger:YODownloadStateFinish]];
                break;
                
            case YODBGetDateOptionAllWaitingData:
                resultSet = [db executeQuery:@"SELECT * FROM t_videoCaches WHERE state = ?", [NSNumber numberWithInteger:YODownloadStateWaiting]];
                break;
                
            default:
                break;
        }
        
        NSMutableArray *tmpArr = [NSMutableArray array];
        while ([resultSet next]) {
            [tmpArr addObject:[[YODownloadModel alloc] initWithFMResultSet:resultSet]];
        }
        array = tmpArr;
    }];
    
    return array;
}

// 更新数据
- (void)updateWithModel:(YODownloadModel *)model option:(YODBUpdateOption)option
{
    [_dbQueue inDatabase:^(FMDatabase *db) {
        if (option & YODBUpdateOptionState) {
            [self postStateChangeNotificationWithFMDatabase:db model:model];
            [db executeUpdate:@"UPDATE t_videoCaches SET state = ? WHERE url = ?", [NSNumber numberWithInteger:model.state], model.url];
        }
        if (option & YODBUpdateOptionLastStateTime) {
            [db executeUpdate:@"UPDATE t_videoCaches SET lastStateTime = ? WHERE url = ?", [NSNumber numberWithInteger:[YOToolBox getTimeStampWithDate:[NSDate date]]], model.url];
        }
        if (option & YODBUpdateOptionResumeData) {
            [db executeUpdate:@"UPDATE t_videoCaches SET resumeData = ? WHERE url = ?", model.resumeData, model.url];
        }
        if (option & YODBUpdateOptionProgressData) {
            [db executeUpdate:@"UPDATE t_videoCaches SET tmpFileSize = ?, totalFileSize = ?, progress = ?, lastSpeedTime = ?, intervalFileSize = ? WHERE url = ?", [NSNumber numberWithInteger:model.tmpFileSize], [NSNumber numberWithFloat:model.totalFileSize], [NSNumber numberWithFloat:model.progress], [NSNumber numberWithInteger:model.lastSpeedTime], [NSNumber numberWithInteger:model.intervalFileSize], model.url];
        }
        if (option & YODBUpdateOptionAllParam) {
            [self postStateChangeNotificationWithFMDatabase:db model:model];
            [db executeUpdate:@"UPDATE t_videoCaches SET resumeData = ?, totalFileSize = ?, tmpFileSize = ?, progress = ?, state = ?, lastSpeedTime = ?, intervalFileSize = ?, lastStateTime = ? WHERE url = ?", model.resumeData, [NSNumber numberWithInteger:model.totalFileSize], [NSNumber numberWithInteger:model.tmpFileSize], [NSNumber numberWithFloat:model.progress], [NSNumber numberWithInteger:model.state], [NSNumber numberWithInteger:model.lastSpeedTime], [NSNumber numberWithInteger:model.intervalFileSize], [NSNumber numberWithInteger:[YOToolBox getTimeStampWithDate:[NSDate date]]], model.url];
        }
    }];
}

// 状态变更通知
- (void)postStateChangeNotificationWithFMDatabase:(FMDatabase *)db model:(YODownloadModel *)model
{
    // 原状态
    NSInteger oldState = [db intForQuery:@"SELECT state FROM t_videoCaches WHERE url = ?", model.url];
    if (oldState != model.state && oldState != YODownloadStateFinish) {
        // 状态变更通知
        [[NSNotificationCenter defaultCenter] postNotificationName:YODownloadStateChangeNotification object:model];
    }
}

// 删除数据
- (void)deleteModelWithUrl:(NSString *)url
{
    [_dbQueue inDatabase:^(FMDatabase *db) {
        BOOL result = [db executeUpdate:@"DELETE FROM t_videoCaches WHERE url = ?", url];
        if (result) {
            //            YOLog(@"删除成功：%@", url);
        }else {
            NSLog(@"删除失败：%@", url);
        }
    }];
}




@end

//
//  YODataBaseManager.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/12.
//  Copyright © 2019 hello. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(NSUInteger, YODBUpdateOption)
{
    
    YODBUpdateOptionState         = 1 << 0,  // 更新状态
    YODBUpdateOptionLastStateTime = 1 << 1,  // 更新状态最后改变的时间
    YODBUpdateOptionResumeData    = 1 << 2,  // 更新下载的数据
    YODBUpdateOptionProgressData  = 1 << 3,  // 更新进度数据（包含tmpFileSize、totalFileSize、progress、intervalFileSize、lastSpeedTime）
    YODBUpdateOptionAllParam      = 1 << 4   // 更新全部数据

};

@interface YODataBaseManager : NSObject

// 获取单例
+ (instancetype)shareManager;

// 插入数据
- (void)insertModel:(YODownloadModel *)model;

// 获取数据
- (YODownloadModel *)getModelWithUrl:(NSString *)url;    // 根据url获取数据
- (YODownloadModel *)getWaitingModel;                    // 获取第一条等待的数据
- (YODownloadModel *)getLastDownloadingModel;            // 获取最后一条正在下载的数据
- (NSArray<YODownloadModel *> *)getAllCacheData;         // 获取所有数据
- (NSArray<YODownloadModel *> *)getAllDownloadingData;   // 根据lastStateTime倒叙获取所有正在下载的数据
- (NSArray<YODownloadModel *> *)getAllDownloadedData;    // 获取所有下载完成的数据
- (NSArray<YODownloadModel *> *)getAllUnDownloadedData;  // 获取所有未下载完成的数据（包含正在下载、等待、暂停、错误）
- (NSArray<YODownloadModel *> *)getAllWaitingData;       // 获取所有等待下载的数据

// 更新数据
- (void)updateWithModel:(YODownloadModel *)model option:(YODBUpdateOption)option;

// 删除数据
- (void)deleteModelWithUrl:(NSString *)url;

@end

NS_ASSUME_NONNULL_END

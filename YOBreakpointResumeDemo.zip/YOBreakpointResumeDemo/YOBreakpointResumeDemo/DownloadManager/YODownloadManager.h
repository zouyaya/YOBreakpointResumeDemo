//
//  YODownloadManager.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/12.
//  Copyright © 2019 hello. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class YODownloadModel;

typedef NS_ENUM(NSInteger,YODownloadState)
{
    YODownloadStateDefault = 0, // 默认
    YODownloadStateDownloading,// 正在下载
    YODownloadStateWaiting,// 等待
    YODownloadStatePaused,// 暂停
    YODownloadStateFinish,// 完成
    YODownloadStateError,// 错误
};

@interface YODownloadManager : NSObject

+(instancetype)shareManager;
/**
 *开始下载
 */
-(void)startDownloadTheTask:(YODownloadModel *)model;
/**
 *暂停下载
 */
-(void)pausedDownloadTheTask:(YODownloadModel *)model;

/**
 *删除下载以及清楚缓存
 */
-(void)deleteTheTaskAndClearCache:(YODownloadModel *)model;


@end

NS_ASSUME_NONNULL_END

//
//  YONetworkReachabilityManager.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/12.
//  Copyright © 2019 hello. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YONetworkReachabilityManager : NSObject

// 当前网络状态
@property (nonatomic, assign, readonly) AFNetworkReachabilityStatus networkReachabilityStatus;

// 获取单例
+ (instancetype)shareManager;

// 监听网络状态
- (void)monitorNetworkStatus;

@end

NS_ASSUME_NONNULL_END

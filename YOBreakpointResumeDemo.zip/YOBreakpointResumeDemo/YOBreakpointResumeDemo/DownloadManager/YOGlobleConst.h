//
//  YOGlobleConst.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/12.
//  Copyright © 2019 hello. All rights reserved.
//

/************************* 下载 *************************/
UIKIT_EXTERN NSString * const YODownloadProgressNotification;                   // 进度回调通知
UIKIT_EXTERN NSString * const YODownloadStateChangeNotification;                // 状态改变通知
UIKIT_EXTERN NSString * const YODownloadMaxConcurrentCountKey;                  // 最大同时下载数量key
UIKIT_EXTERN NSString * const YODownloadMaxConcurrentCountChangeNotification;   // 最大同时下载数量改变通知
UIKIT_EXTERN NSString * const YODownloadAllowsCellularAccessKey;                // 是否允许蜂窝网络下载key
UIKIT_EXTERN NSString * const YODownloadAllowsCellularAccessChangeNotification; // 是否允许蜂窝网络下载改变通知

/************************* 网络 *************************/
UIKIT_EXTERN NSString * const YONetworkingReachabilityDidChangeNotification;    // 网络改变改变通知

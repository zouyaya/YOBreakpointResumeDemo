//
//  YOGlobleConst.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/12.
//  Copyright © 2019 hello. All rights reserved.
//

#import <Foundation/Foundation.h>

/************************* 下载 *************************/
NSString * const YODownloadProgressNotification = @"YODownloadProgressNotification";
NSString * const YODownloadStateChangeNotification = @"YODownloadStateChangeNotification";
NSString * const YODownloadMaxConcurrentCountKey = @"YODownloadMaxConcurrentCountKey";
NSString * const YODownloadMaxConcurrentCountChangeNotification = @"YODownloadMaxConcurrentCountChangeNotification";
NSString * const YODownloadAllowsCellularAccessKey = @"YODownloadAllowsCellularAccessKey";
NSString * const YODownloadAllowsCellularAccessChangeNotification = @"YODownloadAllowsCellularAccessChangeNotification";

/************************* 网络 *************************/
NSString * const YONetworkingReachabilityDidChangeNotification = @"YONetworkingReachabilityDidChangeNotification";


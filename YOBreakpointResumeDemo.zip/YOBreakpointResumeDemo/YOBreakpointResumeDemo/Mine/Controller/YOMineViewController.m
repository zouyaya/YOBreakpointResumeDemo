//
//  YOMineViewController.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOMineViewController.h"
#import "YOMineTableViewCell.h"
#import "YOCacheViewController.h"
#import "YOSettingViewController.h"
#import "YOMainBarViewController.h"

@interface YOMineViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) UITableView *tableView;

@end

@implementation YOMineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navBar.titleLabel.text = @"我的";
    
    [self initializeView];
}


-(void)initializeView
{
    [self.view addSubview:self.tableView];
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 60;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    YOMineTableViewCell *cell = [YOMineTableViewCell cellWithTableView:tableView];
    [cell initTheCellDataWithTheIndexPath:indexPath];
    return cell;
  
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YOMainBarViewController *mainBarVC = (YOMainBarViewController *)  self.navigationController.tabBarController;
    [mainBarVC setTabBarHiddenWithAnimaition:YES];
    if (!indexPath.row) {
        
        YOCacheViewController *cacheVC = [[YOCacheViewController alloc]init];
        [self.navigationController pushViewController:cacheVC animated:YES];
    }else{
        
        YOSettingViewController *settingVC = [[YOSettingViewController alloc]init];
        [self.navigationController pushViewController:settingVC animated:YES];
        
    }
    
}


#pragma mark ----------懒加载
-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0,[[YOIPhoneXAdaptClass shareAdaptClass] returnTheNavBarHeightWithThePhone], ScreenWidth, ScreenHeight - [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight]-[[YOIPhoneXAdaptClass shareAdaptClass] returnTheNavBarHeightWithThePhone]) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    return _tableView;
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

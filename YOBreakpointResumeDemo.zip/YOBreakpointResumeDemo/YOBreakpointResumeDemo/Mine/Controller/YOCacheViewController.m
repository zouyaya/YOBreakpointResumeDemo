//
//  YOCacheViewController.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/13.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOCacheViewController.h"
#import "YOHomeTableViewCell.h"
#import "YOPlayVedioViewController.h"
#import "YOMainBarViewController.h"


@interface YOCacheViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UIButton *navRightBtn;  // 导航右侧删除按钮
@property (nonatomic, weak) UIView *tabbarView;     // 底部工具栏
@property (nonatomic, weak) UIButton *allSelbtn;    // 全选按钮
@property (nonatomic, weak) UIButton *deleteBtn;    // 底部工具栏删除按钮
@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) NSMutableArray<YODownloadModel *> *dataArray;
@property (nonatomic, assign) NSInteger downloadingCount;

@end

@implementation YOCacheViewController

-(void)viewWillAppear:(BOOL)animated
{
    
    [super viewWillAppear:animated];
    
    [self getTheCacheData];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navBar.titleLabel.text = @"缓存";
    
    [self initializeView];
}


-(void)initializeView
{
    
    // 导航右侧按钮
    _navRightBtn = [[UIButton alloc] initWithFrame:CGRectMake(9, 0, 40, 40)];
    [_navRightBtn setImage:[UIImage imageNamed:@"nav_deleteBtn"] forState:UIControlStateNormal];
    [_navRightBtn setImage:[UIImage imageNamed:@"nav_deleteBtn"] forState:UIControlStateHighlighted];
    [_navRightBtn setImage:[UIImage imageNamed:@"nav_cancelBtn"] forState:UIControlStateSelected];
    [_navRightBtn addTarget:self action:@selector(navBtnOnClick:) forControlEvents:UIControlEventTouchUpInside];
    _navRightBtn.center = CGPointMake(ScreenWidth - 20, [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight] - 20);
    [self.navBar addSubview:_navRightBtn];
    
    [self.view addSubview:self.tableView];
    
    
}


-(void)getTheCacheData
{
    // 获取已缓存数据
    self.dataArray = [[[YODataBaseManager shareManager] getAllDownloadedData] mutableCopy];
    [_tableView reloadData];
     _navRightBtn.hidden = self.dataArray.count == 0 ? YES : NO;
    
    // 获取所有未下载完成的数据
    _downloadingCount = [[YODataBaseManager shareManager] getAllUnDownloadedData].count;
  
    
    
    
}



#pragma mark ------------@selector
-(void)backAction
{
    YOMainBarViewController *mainBarVC = (YOMainBarViewController *)  self.navigationController.tabBarController;
    [mainBarVC setTabBarShowWithAnimaition:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

/*

-(void)navBtnOnClick:(UIButton *)btn
{
    
    if (!btn.selected && _tableView.isEditing) [_tableView setEditing:NO animated:YES];
    btn.selected = !btn.selected;
    [_tableView setEditing:!_tableView.editing animated:YES];
    
    if (!btn.selected) [self cancelAllSelect];
    
    CGFloat tabbarY = btn.selected ? ScreenHeight - KNavHeight - _tabbarView.boundsHeight : KMainH - KNavHeight;
    CGFloat tableViewChangeH = _tabbarView.boundsHeight - _tableView.sectionFooterHeight + 5;
    [UIView animateWithDuration:0.25f animations:^{
        _tabbarView.frame = CGRectMake(0, tabbarY, KMainW, _allSelbtn.boundsHeight + KBottomSafeArea);
        _tableView.frameHeight += (btn.selected ? - tableViewChangeH : tableViewChangeH);
    }];
    
    
}

- (void)cancelAllSelect
{
    for (int i = 0; i < self.dataSource.count; i ++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:0];
        [_tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    [_allSelbtn setTitle:@"全选" forState:UIControlStateNormal];
    [_deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
}

*/

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 120;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.0001;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.0001;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return nil;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    YOHomeTableViewCell *cell = [YOHomeTableViewCell cellWithTableView:tableView];
    cell.model = self.dataArray[indexPath.row];
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    YODownloadModel *model = self.dataArray[indexPath.row];
    if (model.state == YODownloadStateFinish) {
    
        YOPlayVedioViewController *playVC = [[YOPlayVedioViewController alloc]init];
        playVC.playModel = model;
        [self.navigationController pushViewController:playVC animated:YES];
    }
    
    
}


#pragma mark --------------懒加载
-(NSMutableArray<YODownloadModel *> *)dataArray
{
    if (!_dataArray) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
    
}

-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, [[YOIPhoneXAdaptClass shareAdaptClass] returnTheNavBarHeightWithThePhone], ScreenWidth, ScreenHeight - [[YOIPhoneXAdaptClass shareAdaptClass] returnTheNavBarHeightWithThePhone] ) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    
    return _tableView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

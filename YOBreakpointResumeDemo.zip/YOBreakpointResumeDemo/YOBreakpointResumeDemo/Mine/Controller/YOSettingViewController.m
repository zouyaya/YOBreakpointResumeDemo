//
//  YOSettingViewController.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/13.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOSettingViewController.h"
#import "YOMainBarViewController.h"
#import "YOMineTableViewCell.h"
#import "YOSetOneTableViewCell.h"
#import "YOSetTwoTableViewCell.h"

@interface YOSettingViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@property (strong, nonatomic) UITableView *tableView;

@end

@implementation YOSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navBar.titleLabel.text = @"设置";
    [self initilizeView];
    
}


-(void)initilizeView
{
    
    [self.view addSubview:self.tableView];
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 60;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (!indexPath.row) {
        
        YOSetOneTableViewCell *cell = [YOSetOneTableViewCell cellWithTableView:tableView];
        cell.infoField.delegate = self;
        cell.infoField.keyboardType = UIKeyboardTypeNumberPad;
        cell.infoField.text = [NSString stringWithFormat:@"%ld", [[NSUserDefaults standardUserDefaults] integerForKey:YODownloadMaxConcurrentCountKey]];
        return cell;
        
    }else if (indexPath.row == 1){
        
        YOSetTwoTableViewCell *cell = [YOSetTwoTableViewCell cellWithTableView:tableView];
        [cell.onswitch addTarget:self action:@selector(accessSwitchOnClick:) forControlEvents:UIControlEventValueChanged];
        return cell;
        
    }
    
    YOMineTableViewCell *cell = [YOMineTableViewCell cellWithTableView:tableView];
    [cell initTheCellDataWithTheIndexPath:indexPath];
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
   
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if ([textField.text isEqualToString:@""]) textField.text = @"1";
    
    
    NSString *countString = textField.text;
    if ([countString integerValue]>5) {
        [SVProgressHUD showInfoWithStatus:@"请重新输入"];
        textField.text = [NSString stringWithFormat:@"%ld", [[NSUserDefaults standardUserDefaults] integerForKey:YODownloadMaxConcurrentCountKey]];
        return;
    }
    // 原并发数
    NSInteger oldCount = [[NSUserDefaults standardUserDefaults] integerForKey:YODownloadMaxConcurrentCountKey];
    // 新并发数
    NSInteger newCount = [textField.text integerValue];
    
    if (oldCount != newCount) {
        // 保存
        [[NSUserDefaults standardUserDefaults] setInteger:newCount forKey:YODownloadMaxConcurrentCountKey];
        // 通知
        [[NSNotificationCenter defaultCenter] postNotificationName:YODownloadMaxConcurrentCountChangeNotification object:[NSNumber numberWithInteger:newCount]];
    }
    
    
}


- (void)accessSwitchOnClick:(UISwitch *)accessSwitch
{
    // 保存
    [[NSUserDefaults standardUserDefaults] setBool:accessSwitch.isOn forKey:YODownloadAllowsCellularAccessKey];
    // 通知
    [[NSNotificationCenter defaultCenter] postNotificationName:YODownloadAllowsCellularAccessChangeNotification object:[NSNumber numberWithBool:accessSwitch.isOn]];
}

#pragma mark ----------懒加载
-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0,[[YOIPhoneXAdaptClass shareAdaptClass] returnTheNavBarHeightWithThePhone], ScreenWidth, ScreenHeight - [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight]-[[YOIPhoneXAdaptClass shareAdaptClass] returnTheNavBarHeightWithThePhone]) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    return _tableView;
    
}



-(void)backAction
{
    YOMainBarViewController *mainBarVC = (YOMainBarViewController *)  self.navigationController.tabBarController;
    [mainBarVC setTabBarShowWithAnimaition:YES];
    [self.navigationController popViewControllerAnimated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

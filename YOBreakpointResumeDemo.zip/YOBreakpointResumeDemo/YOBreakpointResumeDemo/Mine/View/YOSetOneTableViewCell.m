//
//  YOSetOneTableViewCell.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/13.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOSetOneTableViewCell.h"

@interface YOSetOneTableViewCell ()

@property (strong, nonatomic) UILabel *titleLabel;

@property (strong, nonatomic) UIView *lineView;

@end

@implementation YOSetOneTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identify = @"setOnceCell";
    YOSetOneTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (!cell) {
        cell = [[YOSetOneTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identify];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    
    return cell;

}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.backgroundColor = XTColorWithFloat(0x00cdcd);
        
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.text = @"设置下载最大并发数(上限5)";
        _titleLabel.textColor = XTColorWithFloat(0xffffff);
        _titleLabel.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:_titleLabel];
        [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.left.equalTo(self.contentView.mas_left).offset(10);
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.width.equalTo(@(ScreenWidth * 0.75));
            make.height.equalTo(@(50));
        }];
        
        
        _infoField = [[UITextField alloc]init];
        _infoField.text = @"1";
        _infoField.textColor = [UIColor yellowColor];
        _infoField.font = [UIFont systemFontOfSize:18];
        _infoField.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_infoField];
        [_infoField mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.right.equalTo(self.contentView.mas_right).offset(-10);
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.width.equalTo(@(100));
            make.height.equalTo(@(40));
        }];
        
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = XTColorWithFloat(0xf2f2f2);
        [self.contentView addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left);
            make.right.equalTo(self.contentView.mas_right);
            make.bottom.equalTo(self.contentView.mas_bottom);
            make.height.equalTo(@(1));
        }];
        
    }

    return self;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

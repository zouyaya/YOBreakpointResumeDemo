//
//  YOMineTableViewCell.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/13.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOMineTableViewCell.h"

@interface YOMineTableViewCell ()

@property (strong, nonatomic) UILabel *titleLabel;

@property (strong, nonatomic) UIImageView *arrowView;

@property (strong, nonatomic) UIView *lineView;


@end

@implementation YOMineTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identify = @"mineCell";
    YOMineTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (!cell) {
        cell = [[YOMineTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identify];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    
    return cell;
    
    
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.backgroundColor = XTColorWithFloat(0x00cdcd);
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.textColor = XTColorWithFloat(0xffffff);
        _titleLabel.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:_titleLabel];
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left).offset(10);
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.width.equalTo(@(200));
            make.height.equalTo(@50);
        }];
        
        _arrowView = [[UIImageView alloc]init];
        UIImage *arrowImage = [UIImage imageNamed:@"nav_back"];
        _arrowView.image = arrowImage;
        [self.contentView addSubview:_arrowView];
        [_arrowView mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.right.equalTo(self.contentView.mas_right).offset(-10);
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.width.equalTo(@(arrowImage.size.width));
            make.height.equalTo(@(arrowImage.size.height));
        }];
        _arrowView.transform = CGAffineTransformRotate(_arrowView.transform, M_PI);
        
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = XTColorWithFloat(0xf2f2f2);
        [self.contentView addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left);
            make.right.equalTo(self.contentView.mas_right);
            make.bottom.equalTo(self.contentView.mas_bottom);
            make.height.equalTo(@(1));
        }];
        
    }
    
    return self;
    
}

-(void)initTheCellDataWithTheIndexPath:(NSIndexPath *)indexPath
{
    if (!indexPath.row) {
        _titleLabel.text = @"我的缓存";
    }else{
        _titleLabel.text = @"设置";
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

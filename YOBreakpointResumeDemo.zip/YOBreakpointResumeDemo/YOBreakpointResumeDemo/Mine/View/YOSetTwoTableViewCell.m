//
//  YOSetTwoTableViewCell.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/13.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOSetTwoTableViewCell.h"

@interface YOSetTwoTableViewCell ()

@property (strong, nonatomic) UILabel *titleLabel;

@property (strong, nonatomic) UIView *lineView;

@end

@implementation YOSetTwoTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identify = @"setTwoCell";
    YOSetTwoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (!cell) {
        cell = [[YOSetTwoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identify];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    
    return cell;
    
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.backgroundColor = XTColorWithFloat(0x00cdcd);
        
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.text = @"是否允许蜂窝网络下载";
        _titleLabel.textColor = XTColorWithFloat(0xffffff);
        _titleLabel.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:_titleLabel];
        [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.contentView.mas_left).offset(10);
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.width.equalTo(@(ScreenWidth * 0.75));
            make.height.equalTo(@(50));
        }];
        
        
  
        
        _onswitch = [[UISwitch alloc]init];
        [self.contentView addSubview:_onswitch];
        [_onswitch mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.contentView.mas_right).offset(-10);
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.width.equalTo(@(50));
            make.height.equalTo(@(40));
        }];
        
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = XTColorWithFloat(0xf2f2f2);
        [self.contentView addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left);
            make.right.equalTo(self.contentView.mas_right);
            make.bottom.equalTo(self.contentView.mas_bottom);
            make.height.equalTo(@(1));
        }];
        
    }
    
    return self;
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

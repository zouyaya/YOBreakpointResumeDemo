//
//  YOBaseViewController.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YONavBarView.h"

NS_ASSUME_NONNULL_BEGIN

@interface YOBaseViewController : UIViewController

//导航条
@property (strong, nonatomic) YONavBarView *navBar;

@property (strong, nonatomic) UIControl *control;

//action
- (void)backAction;
- (void)rightAction;

@end

NS_ASSUME_NONNULL_END

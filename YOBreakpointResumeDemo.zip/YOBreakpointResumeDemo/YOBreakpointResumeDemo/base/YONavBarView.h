//
//  YONavBarView.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YONavBarView : UIView

@property (strong, nonatomic) UIButton *backBtn;//导航条返回按钮
@property (strong, nonatomic) UIButton *rightBtn;//导航条右按钮
@property (strong, nonatomic) UILabel *lineLabel;//线条
@property (strong, nonatomic) UIImageView *navBackImageView;//导航条背景图
@property (strong, nonatomic) UILabel *titleLabel;//标题内容

@property (strong, nonatomic) UIImageView *leftImageView;

@property (strong, nonatomic) UIColor *color;

@end

NS_ASSUME_NONNULL_END

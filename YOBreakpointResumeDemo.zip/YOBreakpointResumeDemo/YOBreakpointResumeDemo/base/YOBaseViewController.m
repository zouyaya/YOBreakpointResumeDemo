//
//  YOBaseViewController.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOBaseViewController.h"

@interface YOBaseViewController ()

@end

@implementation YOBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.navBar = [[YONavBarView alloc] init];
    [self.navBar.navBackImageView setImage:[UIImage imageFromColor:XTColorWithFloat(0x3696ff)]];
    [self.view addSubview:self.navBar];
    
    //返回按钮
    [self.navBar.backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    //右边按钮
    [self.navBar.rightBtn addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchUpInside];
    
    // 侧滑返回
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    
    if (self.navigationController.viewControllers.count<=1) {
        
        self.navBar.backBtn.hidden = YES;
    }
    
  
    
}

#pragma mark - action
- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightAction
{
    NSLog(@"hhhhh %@",self.navBar.titleLabel.text);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

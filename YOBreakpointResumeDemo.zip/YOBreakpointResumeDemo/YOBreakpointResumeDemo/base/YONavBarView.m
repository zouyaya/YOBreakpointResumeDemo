//
//  YONavBarView.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YONavBarView.h"

@implementation YONavBarView

- (id)init
{
    self = [super init];
    
    if (self) {
        self.userInteractionEnabled = YES;
        self.frame = CGRectMake(0, 0, ScreenWidth, [[YOIPhoneXAdaptClass shareAdaptClass]returnTheNavBarHeightWithThePhone]);
        //背景图
        self.navBackImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth,[[YOIPhoneXAdaptClass shareAdaptClass]returnTheNavBarHeightWithThePhone])];
        self.navBackImageView.backgroundColor = XTColorWithFloat(0x3696ff);
        [self addSubview:self.navBackImageView];
        
        //线条
        self.lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, [[YOIPhoneXAdaptClass shareAdaptClass]returnTheNavBarHeightWithThePhone]-0.5, ScreenWidth, 0.5)];
        self.lineLabel.backgroundColor = ColorWithFloat(0xeeeeee);
        [self addSubview:self.lineLabel];
        
        //标题信息
        self.titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 7+[[YOIPhoneXAdaptClass shareAdaptClass]retunTheStausBarHeight], ScreenWidth - 100, 30)];
        self.titleLabel.textColor = ColorWithFloat(0xffffff);
        self.titleLabel.font = [UIFont systemFontOfSize:18];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.adjustsFontSizeToFitWidth = YES;
        [self addSubview:self.titleLabel];
        
        //左按钮
        self.backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.backBtn.frame = CGRectMake(0, 7+[[YOIPhoneXAdaptClass shareAdaptClass]retunTheStausBarHeight], 60, 30);
        
        self.leftImageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 0, 30, 30)];
        self.leftImageView.userInteractionEnabled = NO;
        self.leftImageView.contentMode = UIViewContentModeCenter;
        [self.leftImageView setImage:[UIImage imageNamed:@"nav_back"]];
        [self.backBtn addSubview:self.leftImageView];
        [self addSubview:self.backBtn];
        
        //右按钮
        self.rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.rightBtn.frame = CGRectMake(ScreenWidth-80, 7+[[YOIPhoneXAdaptClass shareAdaptClass]retunTheStausBarHeight], 80, 30);
        self.rightBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [self.rightBtn setTitleColor:ColorWithFloat(0xffffff) forState:UIControlStateNormal];
        [self addSubview:self.rightBtn];
    }
    
    return self;
}

-(void)setColor:(UIColor *)color
{
    _color = color;
    self.navBackImageView.backgroundColor = _color;
    
    
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

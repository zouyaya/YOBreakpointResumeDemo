//
//  YOPlayVedioViewController.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/13.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOPlayVedioViewController.h"
#import "YOMainBarViewController.h"
#import <AVKit/AVKit.h>

@interface YOPlayVedioViewController ()

@property (strong, nonatomic) AVPlayer *player;

@end

@implementation YOPlayVedioViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navBar.titleLabel.text = _playModel.fileName;
    
    [self initializeView];
}


-(void)initializeView
{
    //进度条
    UISlider *slider = [[UISlider alloc]initWithFrame:CGRectMake(50, 400, ScreenWidth - 100, 30)];
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:slider];
    
    // 播放器
    _player = [AVPlayer playerWithPlayerItem:[AVPlayerItem playerItemWithURL:[NSURL fileURLWithPath:_playModel.localPath]]];
    //创建显示的图层
    AVPlayerLayer *plaerLayer = [AVPlayerLayer playerLayerWithPlayer:_player];
    plaerLayer.frame = CGRectMake(0, 0, ScreenWidth, 400);
    [self.view.layer addSublayer:plaerLayer];
    
    [_player play];
    
    //进度回调
    __weak typeof(self) weakSelf = self;
    [_player addPeriodicTimeObserverForInterval:CMTimeMake(1.0, 1.0) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        slider.value = CMTimeGetSeconds(time)/CMTimeGetSeconds(strongSelf.player.currentItem.duration);
    }];
    
    
}

#pragma mark ----------@selector
-(void)backAction
{
    YOMainBarViewController *mainBarVC = (YOMainBarViewController *)  self.navigationController.tabBarController;
    [mainBarVC setTabBarShowWithAnimaition:YES];
    [self.navigationController popViewControllerAnimated:YES];

}

-(void)sliderValueChanged:(UISlider *)slider
{
    
    // 计算时间
    float time = slider.value * CMTimeGetSeconds(_player.currentItem.duration);
    // 跳转到指定时间
    [_player seekToTime:CMTimeMake(time, 1.0)];
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  YOHomeViewController.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface YOHomeViewController : YOBaseViewController

@end

NS_ASSUME_NONNULL_END

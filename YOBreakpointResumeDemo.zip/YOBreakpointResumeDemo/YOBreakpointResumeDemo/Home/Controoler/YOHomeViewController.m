//
//  YOHomeViewController.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOHomeViewController.h"
#import "YOHomeTableViewCell.h"
#import "YOPlayVedioViewController.h"
#import "YOMainBarViewController.h"

@interface YOHomeViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) UITableView *tableView;

@property (strong, nonatomic) NSMutableArray<YODownloadModel *> *dataArray;

@end

@implementation YOHomeViewController

-(NSMutableArray<YODownloadModel *> *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    
    return _dataArray;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // 获取网络数据
    [self getTheDataSource];
    
    // 获取缓存
    [self getCacheData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navBar.titleLabel.text = @"首页";
    
   
    
    [self initiliazeView];
    
    // 添加通知
    [self addNotification];
    
   
}


-(void)initiliazeView
{
    [self.view addSubview:self.tableView];
    
}

- (void)getCacheData
{
    // 获取已缓存数据
    NSArray *cacheData = [[YODataBaseManager shareManager] getAllCacheData];
    // 这里是把本地缓存数据更新到网络请求的数据中，实际开发还是尽可能避免这样在两个地方取数据再整合
    for (int i = 0; i < self.dataArray.count; i++) {
        YODownloadModel *model = self.dataArray[i];
        for (YODownloadModel *downloadModel in cacheData) {
            if ([model.url isEqualToString:downloadModel.url]) {
                self.dataArray[i] = downloadModel;
                break;
            }
        }
    }
    
    [_tableView reloadData];
}


- (void)addNotification
{
    // 进度通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(downLoadProgress:) name:YODownloadProgressNotification object:nil];
    // 状态改变通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(downLoadStateChange:) name:YODownloadStateChangeNotification object:nil];
}


#pragma mark ----------获取数据源
-(void)getTheDataSource
{
    // 模拟网络数据
    NSArray *testData = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"testData.plist" ofType:nil]];
    NSArray *array = [YODownloadModel mj_objectArrayWithKeyValuesArray:testData];
    [self.dataArray addObjectsFromArray:array];
    
}

#pragma mark -------------UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return self.dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 120;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.0001;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.0001;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return nil;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    YOHomeTableViewCell *cell = [YOHomeTableViewCell cellWithTableView:tableView];
    cell.model = self.dataArray[indexPath.row];
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    YODownloadModel *model = self.dataArray[indexPath.row];
    if (model.state == YODownloadStateFinish) {
      
        YOMainBarViewController *mainBarVC = (YOMainBarViewController *)  self.navigationController.tabBarController;
        [mainBarVC setTabBarHiddenWithAnimaition:YES];
        YOPlayVedioViewController *playVC = [[YOPlayVedioViewController alloc]init];
        playVC.playModel = model;
        [self.navigationController pushViewController:playVC animated:YES];
    }

    
}

#pragma mark - HWDownloadNotification
// 正在下载，进度回调
- (void)downLoadProgress:(NSNotification *)notification
{
    YODownloadModel *downloadModel = notification.object;
    
    [self.dataArray enumerateObjectsUsingBlock:^(YODownloadModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([model.url isEqualToString:downloadModel.url]) {
            // 主线程更新cell进度
            
            dispatch_async(dispatch_get_main_queue(), ^{
                YOHomeTableViewCell *cell = [_tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:idx inSection:0]];
                [cell updateViewWithModel:downloadModel];
            });
            
            *stop = YES;
        }
    }];
}

// 状态改变
- (void)downLoadStateChange:(NSNotification *)notification
{
    YODownloadModel *downloadModel = notification.object;
    
    [self.dataArray enumerateObjectsUsingBlock:^(YODownloadModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([model.url isEqualToString:downloadModel.url]) {
            // 更新数据源
            self.dataArray[idx] = downloadModel;
            // 主线程刷新cell
            dispatch_async(dispatch_get_main_queue(), ^{
                [_tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:idx inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            });
            
            *stop = YES;
        }
    }];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark ------------懒加载
-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, [[YOIPhoneXAdaptClass shareAdaptClass]returnTheNavBarHeightWithThePhone], ScreenWidth, ScreenHeight -[[YOIPhoneXAdaptClass shareAdaptClass]returnTheNavBarHeightWithThePhone]) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    
    return _tableView;
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

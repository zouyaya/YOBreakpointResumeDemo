//
//  YOPlayVedioViewController.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/13.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface YOPlayVedioViewController : YOBaseViewController

/**
 *相关播放的模型
 */
@property (strong, nonatomic) YODownloadModel *playModel;

@end

NS_ASSUME_NONNULL_END

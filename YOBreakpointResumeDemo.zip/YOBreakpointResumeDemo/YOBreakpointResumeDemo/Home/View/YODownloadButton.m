//
//  YODownloadButton.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/2/12.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YODownloadButton.h"

@interface YODownloadButton ()
{
    id _target;
    SEL _action;
    
}

@property (strong, nonatomic) UILabel *proLabel;
@property (strong, nonatomic) UIImageView *imageView;
@end

@implementation YODownloadButton

-(instancetype)init
{
    self = [super init];
    if (self) {
         [self initlializeView];
    }
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self initlializeView];
        
    }
    
    return self;
}

-(void)initlializeView
{
    UILabel *proLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    proLable.font = [UIFont boldSystemFontOfSize:15.0f];
    proLable.textColor = [UIColor colorWithRed:0/255.0 green:191/255.0 blue:255/255.0 alpha:1];
    proLable.textAlignment = NSTextAlignmentCenter;
    [self addSubview:proLable];
    _proLabel = proLable;
    
    
 
    
    // 状态视图
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    _imageView.backgroundColor = [UIColor whiteColor];
    _imageView.image = [UIImage imageNamed:@"com_download_default"];
    [self addSubview:_imageView];
   
    
}

-(void)setProgree:(CGFloat)progree
{
    _progree = progree;
    _proLabel.text = [NSString stringWithFormat:@"%d%%",(int)floor(progree *100)];
    // 不用重新刷新布局，只需重新绘画相关显示的内容
    [self setNeedsDisplay];
    
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
  
    CGFloat lineWidth = 3.0;
    
    UIBezierPath *path = [[UIBezierPath alloc]init];
    path.lineWidth = lineWidth;
    [_proLabel.textColor set];
    
    path.lineCapStyle = kCGLineCapRound;
    path.lineJoinStyle = kCGLineJoinRound;
    
    CGFloat radius = (MIN(rect.size.width, rect.size.height) - lineWidth)/2;
    [path addArcWithCenter:(CGPoint){rect.size.width * 0.5, rect.size.height * 0.5} radius:radius startAngle:M_PI * 1.5 endAngle:M_PI *1.5 + M_PI *2*_progree clockwise:YES];
    [path stroke];
    
}

-(void)setModel:(YODownloadModel *)model
{
    _model = model;
    self.state = model.state;
}


-(void)setState:(YODownloadState)state
{
    
    _imageView.hidden = state == YODownloadStateDownloading;
    _proLabel.hidden = !_imageView.hidden;
    switch (state) {
        case YODownloadStateDefault:
            _imageView.image = [UIImage imageNamed:@"com_download_default"];
            break;
            
        case YODownloadStateDownloading:
            break;
            
        case YODownloadStateWaiting:
            _imageView.image = [UIImage imageNamed:@"com_download_waiting"];
            break;
            
        case YODownloadStatePaused:
            _imageView.image = [UIImage imageNamed:@"com_download_pause"];
            break;
            
        case YODownloadStateFinish:
            _imageView.image = [UIImage imageNamed:@"com_download_finish"];
            break;
            
        case YODownloadStateError:
            _imageView.image = [UIImage imageNamed:@"com_download_error"];
            break;
            
        default:
            break;
    }
    
    _state = state;
    
    
}

-(void)addTarget:(id)target action:(SEL)action
{
    _target = target;
    _action = action;
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (_state == YODownloadStateDefault || _state == YODownloadStatePaused || _state == YODownloadStateError) {
        // 点击默认、暂停、失败状态，调用开始下载
        [[YODownloadManager shareManager] startDownloadTheTask:_model];
        
    }else if (_state == YODownloadStateDownloading || _state == YODownloadStateWaiting) {
        // 点击正在下载、等待状态，调用暂停下载
        [[YODownloadManager shareManager] pausedDownloadTheTask:_model];
    }
    if (!_target || !_action) return;
    ((void (*)(id, SEL, id))[_target methodForSelector:_action])(_target, _action, self);
    
    
}

@end

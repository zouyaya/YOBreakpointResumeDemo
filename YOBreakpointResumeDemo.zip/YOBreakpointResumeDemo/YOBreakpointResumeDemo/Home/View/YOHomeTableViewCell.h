//
//  YOHomeTableViewCell.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/25.
//  Copyright © 2019 hello. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YOHomeTableViewCell : UITableViewCell

@property (strong, nonatomic) YODownloadModel *model;

+(instancetype)cellWithTableView:(UITableView *)tableView;

// 更新视图
- (void)updateViewWithModel:(YODownloadModel *)model;

@end

NS_ASSUME_NONNULL_END

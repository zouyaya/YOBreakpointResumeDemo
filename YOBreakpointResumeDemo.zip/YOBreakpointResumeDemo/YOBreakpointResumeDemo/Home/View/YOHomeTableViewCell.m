//
//  YOHomeTableViewCell.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/25.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOHomeTableViewCell.h"
#import "YODownloadButton.h"

@interface YOHomeTableViewCell()

@property (strong, nonatomic) UIView *bgView;

@property (strong, nonatomic) UILabel *titleLabel;

@property (strong, nonatomic) YODownloadButton *downloadButton;

@property (strong, nonatomic) UILabel *speedLabel;

@property (strong, nonatomic) UILabel *fileSizeLabel;

@end

@implementation YOHomeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identify = @"homeCell";
    YOHomeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (!cell) {
        cell = [[YOHomeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identify];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = XTColorWithFloat(0xffffff);
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        //自定义选中的颜色
        UIView *backgroundView = [[UIView alloc]initWithFrame:cell.frame];
        backgroundView.backgroundColor = XTColorWithFloat(0x00cdcd);
        [cell setSelectedBackgroundView:backgroundView];
        
    }
    
    return cell;
    

}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _bgView = [[UIView alloc]init];
        _bgView.backgroundColor = XTColorWithFloat(0x00cdcd);
        [self.contentView addSubview:_bgView];
        [_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView.mas_left).offset(10);
            make.right.equalTo(self.contentView.mas_right).offset(-10);
            make.top.equalTo(self.contentView.mas_top).offset(10);
            make.bottom.equalTo(self.contentView.mas_bottom);
        }];
        
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.textColor = XTColorWithFloat(0xffffff);
        _titleLabel.font = [UIFont systemFontOfSize:17];
        _titleLabel.text = @"网络视频文件";
        [self.contentView addSubview:_titleLabel];
        [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(self.bgView).offset(10);
          
        }];
        

        // 下载按钮
        CGFloat btnW = 50.f;
        _downloadButton = [[YODownloadButton alloc] init];
        _downloadButton.backgroundColor = [UIColor whiteColor];
        _downloadButton.frame = CGRectMake(ScreenWidth - 20 - btnW, 20, btnW, btnW);
        [_downloadButton addTarget:self action:@selector(downloadOnClick:)];
        [self.contentView addSubview:_downloadButton];
        
        
        
       
        // 进度标签
        _speedLabel = [[UILabel alloc] init];
        _speedLabel.font = [UIFont systemFontOfSize:14.f];
        _speedLabel.textColor = XTColorWithFloat(0xffffff);
        _speedLabel.textAlignment = NSTextAlignmentRight;
        _speedLabel.backgroundColor = _bgView.backgroundColor;
        _speedLabel.layer.masksToBounds = YES;
        [self.contentView addSubview:_speedLabel];
        [_speedLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.bgView.mas_left).offset(100);
            make.bottom.equalTo(self.bgView.mas_bottom).offset(-20);
            make.width.equalTo(@(80));
            make.height.equalTo(@(20));
        }];
        
        // 文件大小标签
         _fileSizeLabel = [[UILabel alloc] init];
        _fileSizeLabel.font = [UIFont systemFontOfSize:14.f];
        _fileSizeLabel.textColor = XTColorWithFloat(0xffffff);
        _fileSizeLabel.textAlignment = NSTextAlignmentRight;
        _fileSizeLabel.backgroundColor = _bgView.backgroundColor;
        _fileSizeLabel.layer.masksToBounds = YES;
        [self.contentView addSubview:_fileSizeLabel];
        [_fileSizeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.speedLabel.mas_right);
            make.top.bottom.width.equalTo(self.speedLabel);
            
        }];
         
   
        
    }
    return self;
    
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    float systemValue = [[[UIDevice currentDevice]systemVersion]floatValue];
    NSArray *subArray = (systemValue >= 11.0) ?  self.superview.subviews : self.subviews;
    NSString *classString = (systemValue >= 11.0) ? @"UISwipeActionPullView" : @"UITableViewCellDeleteConfirmationView";
    for (UIView *view in subArray) {
        if ([view isKindOfClass:NSClassFromString(classString)]) {
            UIButton *deleteBtn = view.subviews.firstObject;
            view.backgroundColor = [UIColor clearColor];
            deleteBtn.frameY = 5;
            deleteBtn.frameHeight = 70;
            [deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
            break;
        }
    }
    
}

-(void)setModel:(YODownloadModel *)model
{
    _model = model;
    _downloadButton.model = model;
    _titleLabel.text = model.fileName;
    [self updateViewWithModel:model];
    
}

// 更新视图
- (void)updateViewWithModel:(YODownloadModel *)model
{
    _downloadButton.progree = model.progress;
    [self reloadLabelWithModel:model];
}

-(void)reloadLabelWithModel:(YODownloadModel *)model
{
    NSString *totalSize = [YOToolBox stringFromByteCount:model.totalFileSize];
    NSString *temSize = [YOToolBox stringFromByteCount:model.tmpFileSize];
    
    NSLog(@"---- %@  %@",totalSize,temSize);
    if (model.state == YODownloadStateFinish) {
        
        _fileSizeLabel.text = totalSize;
    }else{
        
        _fileSizeLabel.text = [NSString stringWithFormat:@"%@ / %@",temSize,totalSize];
        
    }
    
    _fileSizeLabel.hidden = model.totalFileSize == 0;
    
    if (model.speed) {
        
        _speedLabel.text = [NSString stringWithFormat:@"%@/s",[YOToolBox stringFromByteCount:model.speed]];
    }
    
    _speedLabel.hidden = !(model.state == YODownloadStateDownloading && model.totalFileSize > 0);
    
    
}

-(void)downloadOnClick:(YODownloadButton *)button
{
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  YOMainBarViewController.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOBaseTarBarViewController.h"



NS_ASSUME_NONNULL_BEGIN

@interface YOMainBarViewController : YOBaseTarBarViewController

//隐藏TabBar
- (void)setTabBarHiddenWithAnimaition:(BOOL)annimation;

//显示TabBar
- (void)setTabBarShowWithAnimaition:(BOOL)annimation;


@end

NS_ASSUME_NONNULL_END

//
//  YOMainBarViewController.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOMainBarViewController.h"
#import "YOHomeViewController.h"
#import "YOMineViewController.h"
#import "YOTabBarView.h"

@interface YOMainBarViewController ()<YOTabBarViewDelegate>

@property (strong, nonatomic) YOTabBarView *tabBarView;

@end

@implementation YOMainBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //隐藏系统的tabbar
    self.tabBar.alpha = 0.0;
    
    [self creatControl];
    
    [self addViewControllers];
}

- (void)creatControl
{
    //初始化tabBar视图
    YOTabBarView *tabBarView = [[YOTabBarView alloc] initWithFrame:(CGRect){0, ScreenHeight - [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight], ScreenWidth, [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight]}];
    tabBarView.delegate = self;
    [self.view addSubview:tabBarView];
    _tabBarView = tabBarView;
}

- (void)addViewControllers
{
    NSArray *classNameArray = @[@"YOHomeViewController", @"YOMineViewController"];
    NSMutableArray *array = [NSMutableArray array];
    
    for (int i = 0; i < classNameArray.count; i++) {
        YOBaseViewController *vc = [[NSClassFromString(classNameArray[i]) alloc] init];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
        nav.navigationBarHidden = YES;
        [array addObject:nav];
    }
    self.viewControllers = array;
    self.selectedIndex = 0;
}

#pragma mark - HWTabBarViewDelegate
- (void)SKTabBarView:(YOTabBarView *)tabBarView didClickMenuButton:(UIButton *)button
{
    //让所有button归位成非选中状态
    for (int i = 0; i < 3; i ++) {
        UIButton *btn = (UIButton *) [_tabBarView viewWithTag:i + 100];
        [btn setSelected:NO];
    }
    
    //设置当前按钮为选中状态
    button.selected = YES;
    
    //设置当前tabBarController的选中页面
    [self setSelectedIndex:button.tag - 100];
}

//隐藏TabBar
- (void)setTabBarHiddenWithAnimaition:(BOOL)annimation
{
    [UIView animateWithDuration:annimation ? 0.25 : 0 animations:^{
        _tabBarView.frame = CGRectMake(0, ScreenHeight + [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight], ScreenWidth, [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight]);
    }];
}

//显示TabBar
- (void)setTabBarShowWithAnimaition:(BOOL)annimation
{
    [UIView animateWithDuration:annimation ? 0.25 : 0 animations:^{
        _tabBarView.frame = CGRectMake(0, ScreenHeight - [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight], ScreenWidth, [[YOIPhoneXAdaptClass shareAdaptClass] returnTheBottomTabBarHeight]);
    }];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

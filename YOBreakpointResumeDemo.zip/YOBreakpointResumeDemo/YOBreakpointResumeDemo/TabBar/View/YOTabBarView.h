//
//  YOTabBarView.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YOTabBarView;
@protocol YOTabBarViewDelegate <NSObject>
/**
 菜单按钮点击事件
 
 @param tabBarView HWTabBarView
 @param button 菜单按钮
 */
- (void)SKTabBarView:(YOTabBarView *)tabBarView didClickMenuButton:(UIButton *)button;

@end

NS_ASSUME_NONNULL_BEGIN

@interface YOTabBarView : UIView

@property (weak, nonatomic) id<YOTabBarViewDelegate> delegate;

@end

NS_ASSUME_NONNULL_END

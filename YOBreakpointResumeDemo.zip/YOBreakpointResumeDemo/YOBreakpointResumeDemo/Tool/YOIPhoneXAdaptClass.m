//
//  YOIPhoneXAdaptClass.m
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import "YOIPhoneXAdaptClass.h"

@implementation YOIPhoneXAdaptClass

+(instancetype)shareAdaptClass
{
    static YOIPhoneXAdaptClass *adaptClass = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!adaptClass) {
            adaptClass = [[YOIPhoneXAdaptClass alloc]init];
        }
    });
    return adaptClass;
}

-(CGFloat)returnTheNavBarHeightWithThePhone
{
    if (@available(iOS 11.0, *))
    {
        UIWindow * window = [[[UIApplication sharedApplication] delegate] window];
        if (window.safeAreaInsets.bottom > 0.0)
        {
            return 88;
            
        }
        else
        {
            return 64;
        }
    }
    else
    {
        
        return 64;
    }
    return 0;
}

-(CGFloat)retunTheStausBarHeight
{
    if (@available(iOS 11.0, *))
    {
        UIWindow * window = [[[UIApplication sharedApplication] delegate] window];
        if (window.safeAreaInsets.bottom > 0.0)
        {
            return 44;
            
        }
        else
        {
            return 20;
        }
    }
    else
    {
        
        return 20;
    }
    return 0;
    
}

-(CGFloat)returnTheBottomTabBarHeight
{
    if (@available(iOS 11.0, *))
    {
        UIWindow * window = [[[UIApplication sharedApplication] delegate] window];
        if (window.safeAreaInsets.bottom > 0.0)
        {
            return 83;
            
        }
        else
        {
            return 49;
        }
    }
    else
    {
        
        return 49;
    }
    return 0;
    
}

@end

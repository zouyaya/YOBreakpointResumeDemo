//
//  YOIPhoneXAdaptClass.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YOIPhoneXAdaptClass : NSObject

+(instancetype)shareAdaptClass;

/**
 根据手机返回导航栏高度
 */
-(CGFloat)returnTheNavBarHeightWithThePhone;
/**
 返回状态栏的高度
 */
-(CGFloat)retunTheStausBarHeight;
/**
 返回底部tabBar的高度;
 */
-(CGFloat)returnTheBottomTabBarHeight;


@end

NS_ASSUME_NONNULL_END

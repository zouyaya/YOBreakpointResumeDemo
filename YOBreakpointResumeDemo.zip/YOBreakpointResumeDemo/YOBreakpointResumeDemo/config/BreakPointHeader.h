//
//  BreakPointHeader.h
//  YOBreakpointResumeDemo
//
//  Created by yangou on 2019/1/24.
//  Copyright © 2019 hello. All rights reserved.
//

#ifndef BreakPointHeader_h
#define BreakPointHeader_h

#pragma mark - 屏幕高度
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

#pragma mark - 屏幕高度
#define ScreenWidth [UIScreen mainScreen].bounds.size.width

#define ColorWithFloat(rgbValue) \
[UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16)) / 255.0 \
green:((float)((rgbValue & 0xFF00) >> 8)) / 255.0 \
blue:((float)(rgbValue & 0xFF)) / 255.0 alpha:1.0]

// 获得十六进制颜色
#define XTColorWithFloat(rgbValue) \
[UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16)) / 255.0 \
green:((float)((rgbValue & 0xFF00) >> 8)) / 255.0 \
blue:((float)(rgbValue & 0xFF)) / 255.0 alpha:1.0]


#endif /* BreakPointHeader_h */
